set_clock_latency -source -early -min -rise  -0.0758883 [get_ports {core_clk}] -clock myclock 
set_clock_latency -source -early -min -fall  -0.0783205 [get_ports {core_clk}] -clock myclock 
set_clock_latency -source -early -max -rise  -0.0758883 [get_ports {core_clk}] -clock myclock 
set_clock_latency -source -early -max -fall  -0.0783205 [get_ports {core_clk}] -clock myclock 
set_clock_latency -source -late -min -rise  -0.0758883 [get_ports {core_clk}] -clock myclock 
set_clock_latency -source -late -min -fall  -0.0783205 [get_ports {core_clk}] -clock myclock 
set_clock_latency -source -late -max -rise  -0.0758883 [get_ports {core_clk}] -clock myclock 
set_clock_latency -source -late -max -fall  -0.0783205 [get_ports {core_clk}] -clock myclock 
