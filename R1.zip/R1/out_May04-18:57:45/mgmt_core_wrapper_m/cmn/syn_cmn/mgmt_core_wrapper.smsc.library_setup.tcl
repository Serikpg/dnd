################################################################################
#
# Genus(TM) Synthesis Solution setup file
# Created by Genus(TM) Synthesis Solution 22.13-s093_1
#   on 05/04/2026 19:01:01
#
#
################################################################################


# This script is intended for use with Genus(TM) Synthesis Solution version 22.13-s093_1


# To allow user-readonly attributes
################################################################################
::legacy::set_attribute -quiet force_tui_is_remote 1 /


# Libraries
################################################################################
::legacy::set_attribute library {/eda/trasllat/GPDK45/gsclib045_all_v4.7/gsclib045/timing/fast_vdd1v0_basicCells.lib /eda/trasllat/GPDK45/gsclib045_all_v4.7/gsclib045/timing/fast_vdd1v0_multibitsDFF.lib /home/alumnes/j/juli.serra/DNDLabs/prova/synth/caravel-picorv32/R1/../macros/ram_128_1v1_0C.lib} /
